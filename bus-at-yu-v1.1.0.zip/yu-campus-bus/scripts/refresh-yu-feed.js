#!/usr/bin/env node
/**
 * BUS@YU YU PICK public-source refresher.
 * No external npm packages are required (Node 18+ fetch).
 * Writes ONLY data/portal-auto.json; manual content in portal-feed.json is untouched.
 * Website markup can change, so failures are logged and the previous auto file is preserved unless at least one item is collected.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SOURCES = path.join(ROOT, 'data', 'feed-sources.json');
const OUTPUT = path.join(ROOT, 'data', 'portal-auto.json');

function stripHtml(s = '') {
  return s
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalizeDate(raw = '') {
  const m = raw.match(/(20\d{2})[.\/-](\d{1,2})[.\/-](\d{1,2})/);
  if (!m) return '';
  return `${m[1]}-${String(m[2]).padStart(2,'0')}-${String(m[3]).padStart(2,'0')}`;
}

function absoluteUrl(href, source) {
  try { return new URL(href.replaceAll('&amp;', '&'), source.baseUrl || source.url).href; } catch { return null; }
}

function articleId(url) {
  try {
    const u = new URL(url);
    return u.searchParams.get('articleNo') || Buffer.from(url).toString('base64url').slice(0, 22);
  } catch { return Buffer.from(url).toString('base64url').slice(0, 22); }
}

function extractArticles(html, source) {
  const results = [];
  const seen = new Set();
  const re = /<a\b[^>]*href=["']([^"']*(?:articleNo=\d+|mode=view)[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let match;
  while ((match = re.exec(html))) {
    const url = absoluteUrl(match[1], source);
    const title = stripHtml(match[2]);
    if (!url || title.length < 5 || seen.has(url)) continue;
    seen.add(url);
    const context = stripHtml(html.slice(Math.max(0, match.index - 260), Math.min(html.length, re.lastIndex + 300)));
    const publishedAt = normalizeDate(context);
    results.push({
      id: `auto-${source.id}-${articleId(url)}`,
      type: source.type || 'news',
      badge: source.badge || '영대소식',
      icon: source.icon || '📢',
      title: title.slice(0, 90),
      summary: '',
      url,
      source: source.source || '영남대학교',
      publishedAt,
      order: 5000,
      enabled: true,
      auto: true
    });
  }
  results.sort((a,b) => String(b.publishedAt).localeCompare(String(a.publishedAt)) || a.title.localeCompare(b.title, 'ko'));
  return results.slice(0, Number(source.limit) || 10);
}

async function main() {
  const sources = JSON.parse(fs.readFileSync(SOURCES, 'utf8')).filter(x => x && x.enabled !== false && x.url);
  const all = [];
  for (const source of sources) {
    try {
      const res = await fetch(source.url, { headers: { 'User-Agent': 'BUS@YU/1.1 feed refresher (+https://bus.yu.local)' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const html = await res.text();
      const items = extractArticles(html, source);
      console.log(`${source.id}: ${items.length} items`);
      all.push(...items);
    } catch (err) {
      console.warn(`${source.id}: ${err.message}`);
    }
  }
  const deduped = [...new Map(all.map(x => [x.url, x])).values()];
  if (!deduped.length) {
    console.error('No items collected; portal-auto.json left unchanged.');
    process.exitCode = 2;
    return;
  }
  fs.writeFileSync(OUTPUT + '.tmp', JSON.stringify(deduped, null, 2) + '\n');
  fs.renameSync(OUTPUT + '.tmp', OUTPUT);
  console.log(`Wrote ${deduped.length} items -> ${OUTPUT}`);
}

main().catch(err => { console.error(err); process.exit(1); });
