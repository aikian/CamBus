# CHANGELOG

모든 주요 변경사항은 이 파일에 기록합니다.

버전 규칙은 Semantic Versioning(`MAJOR.MINOR.PATCH`)을 사용합니다.

## [1.1.0] - 2026-08-29

### Added

- 노선 위 시간표 예상 버스 마커 부드러운 이동 애니메이션
- 버스 마커 다음 정류장 ETA 표시
- 정류장 팝업 다음 2개 버스 ETA
- 구간별 실측 ETA 오버라이드 파일 `data/route-timings.json`
- 탑승객 공유 위치 마커 ETA/이동 애니메이션
- YU PICK 자동수집 데이터 `data/portal-auto.json` 및 수집 스크립트
- 기간형 지역 직접광고 데이터 `data/local-ads.json`
- 길찾기/안내/탑승/YU PICK 클릭 집계 `data/metrics.json`
- PM 존 전용 데이터 `data/pm-zones.json`
- 자동수집 소스 설정 `data/feed-sources.json`
- `TEST_REPORT.md` 검수 기록

### Changed

- 실제 실측 구간시간이 없으면 기존 OSRM 구간시간으로 자동 폴백
- 크라우드 탑승자 위치가 존재하는 운행편은 시간표 예상 마커보다 우선 표시
- Service Worker 캐시 대상에 v1.1.0 데이터 파일 추가

### Known limitations

- 실제 차량 GPS는 제공되지 않음
- `route-timings.json`의 실측 구간시간은 아직 미입력 상태이며 OSRM 폴백 사용
- 자동수집 스크립트는 대상 학교 페이지 구조/네트워크 상태에 따라 실패할 수 있으며 수동 피드는 보존됨
- 컨테이너의 Chromium 네트워크 대기 문제로 전체 외부 지도 타일/라우팅 E2E는 제한적으로 검증됨

## [1.0.0] - 2026-08-29

### Added

- BUS@YU / YU PICK 좌우 2페이지 구조
- OpenStreetMap 기반 영남대 캠퍼스 지도
- 1노선/2노선 정류장 및 노선 표시
- 2026학년도 2학기 배차표 반영
- 시간표 기반 버스 예상 위치와 ETA
- 도보 / 도보+순환버스 경로 비교
- 승차/하차 Guidance 및 브라우저 알림 구조
- 탑승자 동의형 익명 위치 공유
- 사용자 신고형 혼잡도
- PM/전동킥보드 주차 레이어
- 세션 최초 대형 광고 슬롯
- 메인 하단 얇은 광고 슬롯
- YU PICK 세로형 배너/카드 피드
- YU PICK 콘텐츠 5개당 광고 1개 자동 삽입
- `ad@uxo.kr` 지역 광고 모집 하우스 배너
- YU PICK 최하단 오늘/이번달 사용자 수
- YU PICK 사용자 통계 아래 별도 광고 배너
- `data/portal-feed.json` 파일 기반 콘텐츠 운영
- 초기 공개 데이터 20개 수집/시드
- Ezoic launch / bottom / feed placement 연결 어댑터
- PWA Manifest 및 Service Worker
- 버전 파일 `VERSION`
- SRS / README / DATA_SOURCES 문서화

### Changed

- 우측 페이지를 기존 4열 앱 아이콘 방식에서 세로형 생활정보 피드로 전환
- 유용한 사이트 데이터 소스를 `data/useful-sites.json`에서 `data/portal-feed.json`으로 변경
- API를 `/api/useful-sites`에서 `/api/portal-feed`로 변경

### Notes

- 실제 차량 GPS는 연결되어 있지 않음
- 시간표 ETA는 실제 GPS와 구분하여 표시
- 식당/카페 데이터는 공개 지역 검색을 바탕으로 한 초기 추천이며 운영 중 주기적 검수 필요
