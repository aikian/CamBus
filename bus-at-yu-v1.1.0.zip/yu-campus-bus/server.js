#!/usr/bin/env node
/**
 * BUS@YU prototype server
 * - Static files
 * - Ephemeral crowd bus telemetry (TTL 120s)
 * - Ephemeral crowding reports (TTL 30m)
 * - YU PICK vertical feed from data/portal-feed.json
 * - Persistent anonymous unique-browser counts for today / current month
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8080);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const PORTAL_FEED_FILE = path.join(DATA_DIR, 'portal-feed.json');
const PORTAL_AUTO_FILE = path.join(DATA_DIR, 'portal-auto.json');
const LOCAL_ADS_FILE = path.join(DATA_DIR, 'local-ads.json');
const PM_ZONES_FILE = path.join(DATA_DIR, 'pm-zones.json');
const VISITOR_STATS_FILE = path.join(DATA_DIR, 'visitor-stats.json');
const METRICS_FILE = path.join(DATA_DIR, 'metrics.json');
const TELEMETRY_TTL_MS = 120_000;
const CROWD_TTL_MS = 30 * 60_000;
const MAX_BODY = 16 * 1024;
const CAMPUS = { minLat: 35.8200, maxLat: 35.8420, minLng: 128.7460, maxLng: 128.7680 };
const ROUTES = new Set(['r1', 'r2']);
const CROWD_LEVELS = new Set(['quiet', 'normal', 'crowded', 'full']);

const telemetry = new Map();
const crowdReports = new Map();
const rate = new Map();

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(PORTAL_FEED_FILE)) fs.writeFileSync(PORTAL_FEED_FILE, '[]\n');
if (!fs.existsSync(PORTAL_AUTO_FILE)) fs.writeFileSync(PORTAL_AUTO_FILE, '[]\n');
if (!fs.existsSync(LOCAL_ADS_FILE)) fs.writeFileSync(LOCAL_ADS_FILE, '[]\n');
if (!fs.existsSync(PM_ZONES_FILE)) fs.writeFileSync(PM_ZONES_FILE, '[]\n');
if (!fs.existsSync(METRICS_FILE)) fs.writeFileSync(METRICS_FILE, '{\n  \"days\": {},\n  \"months\": {}\n}\n');
if (!fs.existsSync(VISITOR_STATS_FILE)) fs.writeFileSync(VISITOR_STATS_FILE, '{\n  "days": {},\n  "months": {}\n}\n');

let visitorStats = loadVisitorStats();
let metrics = loadMetrics();

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.md': 'text/markdown; charset=utf-8'
};

function json(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Content-Length': Buffer.byteLength(payload)
  });
  res.end(payload);
}

function prune(now = Date.now()) {
  for (const [key, row] of telemetry) if (row.expiresAt <= now) telemetry.delete(key);
  for (const [key, row] of crowdReports) if (row.expiresAt <= now) crowdReports.delete(key);
  for (const [key, row] of rate) if (row.windowStart + 60_000 <= now) rate.delete(key);
}

function allow(req, limit = 120) {
  const ip = req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  let row = rate.get(ip);
  if (!row || row.windowStart + 60_000 <= now) row = { windowStart: now, count: 0 };
  row.count += 1;
  rate.set(ip, row);
  return row.count <= limit;
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) {
        reject(Object.assign(new Error('payload too large'), { status: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(Object.assign(new Error('invalid json'), { status: 400 }));
      }
    });
    req.on('error', reject);
  });
}

function validToken(v) {
  return typeof v === 'string' && v.length >= 8 && v.length <= 128 && /^[A-Za-z0-9._:-]+$/.test(v);
}
function validTrip(v) {
  return typeof v === 'string' && v.length >= 4 && v.length <= 40 && /^[A-Za-z0-9:_-]+$/.test(v);
}
function validCoord(lat, lng) {
  return Number.isFinite(lat) && Number.isFinite(lng) && lat >= CAMPUS.minLat && lat <= CAMPUS.maxLat && lng >= CAMPUS.minLng && lng <= CAMPUS.maxLng;
}
function safeHttpUrl(value) {
  try {
    const u = new URL(String(value));
    return (u.protocol === 'http:' || u.protocol === 'https:') ? u.href : null;
  } catch { return null; }
}

function median(nums) {
  if (!nums.length) return null;
  const a = [...nums].sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}

function liveBusAggregates(now = Date.now()) {
  prune(now);
  const groups = new Map();
  for (const row of telemetry.values()) {
    const key = `${row.routeId}|${row.tripKey}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  const out = [];
  for (const rows of groups.values()) {
    const lat = median(rows.map(x => x.lat));
    const lng = median(rows.map(x => x.lng));
    const newest = Math.max(...rows.map(x => x.serverTimestamp));
    out.push({
      routeId: rows[0].routeId,
      tripKey: rows[0].tripKey,
      lat: Number(lat.toFixed(5)),
      lng: Number(lng.toFixed(5)),
      contributors: rows.length,
      sampleAgeSeconds: Math.max(0, Math.round((now - newest) / 1000)),
      source: 'crowd'
    });
  }
  return out;
}

function crowdingAggregates(now = Date.now()) {
  prune(now);
  const weights = { quiet: 1, normal: 2, crowded: 3, full: 4 };
  const labels = ['quiet', 'normal', 'crowded', 'full'];
  const groups = new Map();
  for (const row of crowdReports.values()) {
    const key = `${row.routeId}|${row.tripKey}`;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(row);
  }
  const out = [];
  for (const rows of groups.values()) {
    const avg = rows.reduce((s, x) => s + weights[x.level], 0) / rows.length;
    const idx = Math.max(0, Math.min(3, Math.round(avg) - 1));
    const newest = Math.max(...rows.map(x => x.createdAt));
    out.push({
      routeId: rows[0].routeId,
      tripKey: rows[0].tripKey,
      level: labels[idx],
      reports: rows.length,
      updatedSecondsAgo: Math.max(0, Math.round((now - newest) / 1000))
    });
  }
  return out;
}

function readJsonFile(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}

function sanitizeFeedList(parsed, origin = 'manual') {
  const list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.items) ? parsed.items : []);
  return list
    .filter(item => item && item.enabled !== false && typeof item.title === 'string' && safeHttpUrl(item.url))
    .map((item, index) => ({
      id: String(item.id || `${origin}-feed-${index + 1}`).slice(0, 80),
      type: typeof item.type === 'string' ? item.type.trim().slice(0, 30) : 'utility',
      badge: typeof item.badge === 'string' ? item.badge.trim().slice(0, 20) : '정보',
      icon: typeof item.icon === 'string' ? item.icon.trim().slice(0, 32) : '↗',
      title: item.title.trim().slice(0, 90),
      summary: typeof item.summary === 'string' ? item.summary.trim().slice(0, 260) : '',
      url: safeHttpUrl(item.url),
      source: typeof item.source === 'string' ? item.source.trim().slice(0, 100) : '',
      publishedAt: typeof item.publishedAt === 'string' ? item.publishedAt.trim().slice(0, 20) : '',
      order: Number.isFinite(Number(item.order)) ? Number(item.order) : 9999,
      origin
    }));
}

function loadPortalFeed() {
  const manual = sanitizeFeedList(readJsonFile(PORTAL_FEED_FILE, []), 'manual');
  const auto = sanitizeFeedList(readJsonFile(PORTAL_AUTO_FILE, []), 'auto');
  const byUrl = new Map();
  // Manual entries win over automatically collected duplicates.
  for (const item of auto) byUrl.set(item.url, item);
  for (const item of manual) byUrl.set(item.url, item);
  return [...byUrl.values()].sort((a, b) => {
    if (a.origin !== b.origin && a.order !== b.order) return a.order - b.order;
    const dateCmp = String(b.publishedAt || '').localeCompare(String(a.publishedAt || ''));
    return (a.order - b.order) || dateCmp || a.title.localeCompare(b.title, 'ko');
  });
}

function activeLocalAds(now = new Date()) {
  const parsed = readJsonFile(LOCAL_ADS_FILE, []);
  const list = Array.isArray(parsed) ? parsed : [];
  return list.filter(ad => {
    if (!ad || ad.enabled === false || !ad.title || !ad.url) return false;
    const start = ad.startsAt ? new Date(ad.startsAt) : null;
    const end = ad.endsAt ? new Date(ad.endsAt) : null;
    if (start && !Number.isNaN(start.valueOf()) && now < start) return false;
    if (end && !Number.isNaN(end.valueOf()) && now > end) return false;
    return true;
  }).map((ad, i) => ({
    id: String(ad.id || `ad-${i + 1}`).slice(0,80),
    kind: String(ad.kind || 'local').slice(0,20),
    title: String(ad.title).slice(0,100),
    subtitle: String(ad.subtitle || '').slice(0,180),
    cta: String(ad.cta || '자세히').slice(0,40),
    url: String(ad.url).startsWith('mailto:') ? String(ad.url) : safeHttpUrl(ad.url),
    image: ad.image ? safeHttpUrl(ad.image) : null,
    startsAt: ad.startsAt || null,
    endsAt: ad.endsAt || null,
    weight: Math.max(1, Math.min(100, Number(ad.weight) || 1))
  })).filter(ad => ad.url);
}

function loadPmZones() {
  const parsed = readJsonFile(PM_ZONES_FILE, []);
  return (Array.isArray(parsed) ? parsed : []).filter(x => x && x.enabled !== false && x.name).map((x,i) => ({
    id: String(x.id || `pm-${i+1}`).slice(0,80),
    name: String(x.name).slice(0,100),
    type: String(x.type || 'pm_parking').slice(0,40),
    coord: Array.isArray(x.coord) && x.coord.length === 2 && validCoord(Number(x.coord[0]), Number(x.coord[1])) ? [Number(x.coord[0]), Number(x.coord[1])] : null,
    searchAliases: Array.isArray(x.searchAliases) ? x.searchAliases.map(v => String(v).slice(0,60)).slice(0,8) : [],
    confidence: String(x.confidence || 'unknown').slice(0,30),
    note: String(x.note || '').slice(0,320),
    sourceTitle: String(x.sourceTitle || '').slice(0,120),
    sourceUrl: x.sourceUrl ? safeHttpUrl(x.sourceUrl) : null
  }));
}

function loadMetrics() {
  const parsed = readJsonFile(METRICS_FILE, {days:{}, months:{}});
  return { days: parsed?.days || {}, months: parsed?.months || {} };
}

function persistMetrics() {
  const temp = METRICS_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(metrics, null, 2) + '\n');
  fs.renameSync(temp, METRICS_FILE);
}

const METRIC_EVENTS = new Set(['route_search','guidance_start','ride_boarded','feed_click','pm_open']);
function recordMetric(type, payload = {}) {
  if (!METRIC_EVENTS.has(type)) return false;
  const { day, month } = koreaDateKeys();
  for (const [bucketName, key] of [['days',day], ['months',month]]) {
    const bucket = metrics[bucketName];
    if (!bucket[key] || typeof bucket[key] !== 'object') bucket[key] = { events: {}, destinations: {}, feedClicks: {} };
    const row = bucket[key];
    row.events[type] = (Number(row.events[type]) || 0) + 1;
    if (type === 'route_search' && typeof payload.destination === 'string' && payload.destination && payload.destination !== '지도에서 선택한 위치') {
      const d = payload.destination.slice(0,80);
      row.destinations[d] = (Number(row.destinations[d]) || 0) + 1;
    }
    if (type === 'feed_click' && typeof payload.itemId === 'string') {
      const id = payload.itemId.slice(0,80);
      row.feedClicks[id] = (Number(row.feedClicks[id]) || 0) + 1;
    }
  }
  persistMetrics();
  return true;
}

function loadVisitorStats() {
  try {
    const parsed = JSON.parse(fs.readFileSync(VISITOR_STATS_FILE, 'utf8'));
    return {
      days: parsed && typeof parsed.days === 'object' && parsed.days ? parsed.days : {},
      months: parsed && typeof parsed.months === 'object' && parsed.months ? parsed.months : {}
    };
  } catch {
    return { days: {}, months: {} };
  }
}

function koreaDateKeys(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(date).reduce((acc, p) => { acc[p.type] = p.value; return acc; }, {});
  const day = `${parts.year}-${parts.month}-${parts.day}`;
  return { day, month: `${parts.year}-${parts.month}` };
}

function pruneVisitorStats() {
  const dayKeys = Object.keys(visitorStats.days).sort();
  const monthKeys = Object.keys(visitorStats.months).sort();
  dayKeys.slice(0, Math.max(0, dayKeys.length - 70)).forEach(k => delete visitorStats.days[k]);
  monthKeys.slice(0, Math.max(0, monthKeys.length - 24)).forEach(k => delete visitorStats.months[k]);
}

function persistVisitorStats() {
  pruneVisitorStats();
  const temp = VISITOR_STATS_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(visitorStats, null, 2) + '\n');
  fs.renameSync(temp, VISITOR_STATS_FILE);
}

function visitorCounts() {
  const { day, month } = koreaDateKeys();
  const today = Array.isArray(visitorStats.days[day]) ? visitorStats.days[day].length : 0;
  const monthCount = Array.isArray(visitorStats.months[month]) ? visitorStats.months[month].length : 0;
  return { today, month: monthCount, dayKey: day, monthKey: month };
}

function registerVisitor(visitorToken) {
  const digest = crypto.createHash('sha256').update(`BUS@YU:${visitorToken}`).digest('hex');
  const { day, month } = koreaDateKeys();
  if (!Array.isArray(visitorStats.days[day])) visitorStats.days[day] = [];
  if (!Array.isArray(visitorStats.months[month])) visitorStats.months[month] = [];
  let changed = false;
  if (!visitorStats.days[day].includes(digest)) { visitorStats.days[day].push(digest); changed = true; }
  if (!visitorStats.months[month].includes(digest)) { visitorStats.months[month].push(digest); changed = true; }
  if (changed) persistVisitorStats();
  return visitorCounts();
}

async function api(req, res, pathname) {
  if (!allow(req)) return json(res, 429, { error: 'rate_limited' });
  prune();

  if (req.method === 'GET' && pathname === '/api/health') {
    return json(res, 200, { ok: true, service: 'bus-at-yu', now: new Date().toISOString() });
  }
  if (req.method === 'GET' && pathname === '/api/live-buses') {
    return json(res, 200, { buses: liveBusAggregates() });
  }
  if (req.method === 'GET' && pathname === '/api/crowding') {
    return json(res, 200, { crowding: crowdingAggregates() });
  }
  if (req.method === 'GET' && pathname === '/api/portal-feed') {
    return json(res, 200, { items: loadPortalFeed() });
  }
  if (req.method === 'GET' && pathname === '/api/local-ads') {
    return json(res, 200, { ads: activeLocalAds() });
  }
  if (req.method === 'GET' && pathname === '/api/pm-zones') {
    return json(res, 200, { zones: loadPmZones() });
  }
  if (req.method === 'GET' && pathname === '/api/metrics') {
    const { day, month } = koreaDateKeys();
    return json(res, 200, { day: metrics.days[day] || {}, month: metrics.months[month] || {} });
  }
  if (req.method === 'GET' && pathname === '/api/visitors') {
    return json(res, 200, visitorCounts());
  }

  if (req.method === 'POST' && pathname === '/api/visit') {
    const body = await readJson(req);
    if (!validToken(body.visitorToken)) return json(res, 400, { error: 'invalid_visitor_token' });
    return json(res, 200, registerVisitor(body.visitorToken));
  }

  if (req.method === 'POST' && pathname === '/api/event') {
    const body = await readJson(req);
    if (!METRIC_EVENTS.has(body.type)) return json(res, 400, { error: 'invalid_event' });
    recordMetric(body.type, body.payload && typeof body.payload === 'object' ? body.payload : {});
    return json(res, 202, { ok: true });
  }

  if (req.method === 'POST' && pathname === '/api/telemetry') {
    const body = await readJson(req);
    const { riderToken, routeId, tripKey } = body;
    const lat = Number(body.lat), lng = Number(body.lng), accuracy = Number(body.accuracy);
    if (!validToken(riderToken) || !ROUTES.has(routeId) || !validTrip(tripKey) || !validCoord(lat, lng)) {
      return json(res, 400, { error: 'invalid_telemetry' });
    }
    if (Number.isFinite(accuracy) && (accuracy < 0 || accuracy > 500)) return json(res, 400, { error: 'invalid_accuracy' });
    const now = Date.now();
    telemetry.set(riderToken, {
      riderToken, routeId, tripKey, lat, lng,
      accuracy: Number.isFinite(accuracy) ? accuracy : null,
      clientTimestamp: Number.isFinite(Number(body.clientTimestamp)) ? Number(body.clientTimestamp) : null,
      serverTimestamp: now,
      expiresAt: now + TELEMETRY_TTL_MS
    });
    return json(res, 202, { ok: true, expiresInSeconds: TELEMETRY_TTL_MS / 1000 });
  }

  if (req.method === 'POST' && pathname === '/api/crowding') {
    const body = await readJson(req);
    const { reportToken, routeId, tripKey, level } = body;
    if (!validToken(reportToken) || !ROUTES.has(routeId) || !validTrip(tripKey) || !CROWD_LEVELS.has(level)) {
      return json(res, 400, { error: 'invalid_crowding_report' });
    }
    const now = Date.now();
    const key = `${reportToken}:${routeId}:${tripKey}`;
    crowdReports.set(key, { reportToken, routeId, tripKey, level, createdAt: now, expiresAt: now + CROWD_TTL_MS });
    return json(res, 202, { ok: true, expiresInSeconds: CROWD_TTL_MS / 1000 });
  }

  return json(res, 404, { error: 'not_found' });
}

function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  try { rel = decodeURIComponent(rel); } catch { return json(res, 400, { error: 'bad_path' }); }
  const file = path.resolve(ROOT, '.' + rel);
  if (!file.startsWith(ROOT + path.sep)) return json(res, 403, { error: 'forbidden' });
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not found');
      return;
    }
    const type = mime[path.extname(file).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'Cache-Control': path.basename(file) === 'sw.js' ? 'no-cache' : 'public, max-age=60'
    });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url.pathname);
    return serveStatic(req, res, url.pathname);
  } catch (e) {
    console.error(e);
    return json(res, e.status || 500, { error: e.message || 'server_error' });
  }
});

server.listen(PORT, () => {
  console.log(`BUS@YU running at http://localhost:${PORT}`);
  console.log(`Portal feed files: ${PORTAL_FEED_FILE}, ${PORTAL_AUTO_FILE}`);
  console.log('Crowd telemetry stays in memory; visitor counts are stored as token hashes only.');
});
